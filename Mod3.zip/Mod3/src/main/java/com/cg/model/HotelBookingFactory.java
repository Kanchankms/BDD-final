package com.cg.model;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingFactory
{
	WebDriver driver;

		
	//@FindBy used to map with element in html page
	
	@FindBy(id="txtFirstName")				
	@CacheLookup
	WebElement firstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath=".//*[@id='txtPhone']")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement confirmBookingBtn;
	
	@FindBy(name="city")
	WebElement city;
	
	@FindBy(name="state")
	WebElement state;
	
	@FindBy(id="txtCardholderName")
	WebElement cardHolderName;
	
	@FindBy(id="txtDebit")
	WebElement debitCardNo;
	
	@FindBy(id="txtCvv")
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	WebElement expMonth;
	
	@FindBy(id="txtYear")
	WebElement expYear;
	
	@FindBy(id="txtGender1")
	WebElement gender1;
	
	@FindBy(id="txtGender2")
	WebElement gender2;
	
	@FindBy(xpath="html/body/div[1]/div/form/table/tbody/tr[12]/td[2]/input[1]")
	WebElement check1;
	
	@FindBy(xpath="html/body/div[1]/div/form/table/tbody/tr[12]/td[2]/input[2]")
	WebElement check2;
	
	
	
	public HotelBookingFactory(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public HotelBookingFactory() {
		super();
	}


	public void setFirstName(String fname)
	{
		firstName.sendKeys(fname);
	}
	
	public String getCity() {
		String cityName = city.getText();
		return cityName;
	}
	public void setcity(String cityName) {
		city.sendKeys(cityName);
		
	}

	

	public void setLastName(String lname)
	{
		lastName.sendKeys(lname);
	}



	public void setEmail(String e)
	{
		email.sendKeys(e);
	}

	

	public void setMobileNo(String mobNo)
	{
		mobileNo.sendKeys(mobNo);
	}
	
	public void setGender(String gen)
	{
		if(gen.equalsIgnoreCase("Female"))
			gender2.click();
		else
			gender1.click();		
	}
	
	
	public void setRoomType(String type)
	{
		if(type.equalsIgnoreCase("AC"))
			check1.click();
		else
			check2.click();		
	}
	
	

	
	public String getState() {
		String stateName = state.getText();
		return stateName;
	}
	public void setState(String stateName) {
		state.sendKeys(stateName);
		
	}
	
	public void setCardHolderName(String cHolderName) {
		cardHolderName.sendKeys(cHolderName);
		
	}
	
	public void setDebitNo(String dbtNo) {
		debitCardNo.sendKeys(dbtNo);
		
	}
	
	public void setCvv(String c) {
		cvv.sendKeys(c);
		
	}
	
	public void setExpMonth(String expM) {
		expMonth.sendKeys(expM);
		
	}
	
	public void setExpYear(String expY) {
		expYear.sendKeys(expY);
		
	}


	

	
	public void clickConfirmButton()
	{
		confirmBookingBtn.click();
	}
}
