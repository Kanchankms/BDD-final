package hotelbookingform;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.model.HotelBookingFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookStepDefN
{
	HotelBookingFactory bookingPage;
	WebDriver driver;

	@Given("^User is on hotelbooking page$")
	public void user_is_on_hotelbooking_page() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver", "D:\\BDD software\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D:\\BDD software\\BDD STS Projects\\HotelBookingDemo\\hotelbooking.html");
		bookingPage= new HotelBookingFactory(driver);
		System.out.println("webpage displayed");
	}

	@When("^FirstName is Blank$")
	public void firstname_is_Blank() throws Throwable 
	{
		bookingPage.setFirstName("");
		System.out.println("Name set as blank");
		bookingPage.clickConfirmButton();
		System.out.println("clicked on booking button...");
	}

	@Then("^Display Alert 'Please fill the First Name'$")
	public void display_Alert_please_enter_firstname() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the First Name";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^LastName is Blank$")
	public void lastname_is_Blank() throws Throwable 
	{

		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display Alert 'Please fill the Last Name'$")
	public void display_Alert_Please_fill_the_Last_Name() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the Last Name";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^Email is blank$")
	public void email_is_blank() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display Alert 'Please enter email'$")
	public void display_Alert_Please_enter_email() throws Throwable 
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the Email";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^Email is invalid$")
	public void email_is_invalid() throws Throwable 
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("kanchanhklo.com");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display Alert 'Please enter valid email'$")
	public void display_Alert_Please_enter_valid_email() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please enter valid Email Id.";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close(); 
	}

	@When("^mobileNo\\. is Blank$")
	public void mobileno_is_Blank() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display Alert 'Please fill the mobileNo\\.'$")
	public void display_Alert_Please_fill_the_mobileNo() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the Mobile No.";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^mobileNo\\. is invalid$")
	public void mobileno_is_invalid() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("12345");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display Alert 'Please enter valid mobileNo\\.'$")
	public void display_Alert_Please_enter_valid_mobileNo() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please enter valid Contact no.";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^user entered invalid mobile no\\.$")
	public void user_entered_invalid_mobile_no() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("5678904321");
		bookingPage.clickConfirmButton();
	}

	@When("^user not selected gender$")
	public void user_not_selected_gender() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.clickConfirmButton();
	}

	@Then("^display alert for Gender field$")
	public void display_alert_for_Gender_field() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please Select the Gender";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^User not selected city$")
	public void user_not_selected_city() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display alert for city field$")
	public void display_alert_for_city_field() throws Throwable
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please select city";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}


	@When("^User not selected state$")
	public void user_not_selected_state() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.clickConfirmButton();

	}

	@Then("^Display alert for state field$")
	public void display_alert_for_state_field() throws Throwable {
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please select state";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^user not selected room type$")
	public void user_not_selected_room_type() throws Throwable 
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.clickConfirmButton();

	}

	@Then("^display alert for room  field$")
	public void display_alert_for_room_field() throws Throwable 
	{
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please select the Room type";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}


	@When("^User not entered card holder name$")
	public void user_not_entered_card_holder_name() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.setRoomType("ac");
		bookingPage.clickConfirmButton();

	}

	@Then("^Display alert 'please enter card holder name'$")
	public void display_alert_please_enter_card_holder_name() throws Throwable {
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the Card holder name";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^User not entered Debit card number$")
	public void user_not_entered_Debit_card_number() throws Throwable
	{

		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.setRoomType("AC");
		bookingPage.setCardHolderName("Kanchan Kumari");
		bookingPage.clickConfirmButton();
	}

	@Then("^Display alert 'please enter debit card number'$")
	public void display_alert_please_enter_debit_card_number() throws Throwable {
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the Debit card Number";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^User not entered cvv$")
	public void user_not_entered_cvv() throws Throwable 
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.setRoomType("AC");
		bookingPage.setCardHolderName("Kanchan Kumari");
		bookingPage.setDebitNo("458546003211");
		bookingPage.clickConfirmButton();

	}

	@Then("^Display alert 'please enter cvv'$")
	public void display_alert_please_enter_cvv() throws Throwable {
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the CVV";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^User not entered expiration month$")
	public void user_not_entered_expiration_month() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.setRoomType("AC");
		bookingPage.setCardHolderName("Kanchan Kumari");
		bookingPage.setDebitNo("458546003211");
		bookingPage.setCvv("222");
		bookingPage.clickConfirmButton();

	}

	@Then("^Display alert 'please enter expiration month'$")
	public void display_alert_please_enter_expiration_month() throws Throwable {
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill expiration month";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}

	@When("^User not entered expiration year$")
	public void user_not_entered_expiration_year() throws Throwable 
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.setRoomType("AC");
		bookingPage.setCardHolderName("Kanchan Kumari");
		bookingPage.setDebitNo("458546003211");
		bookingPage.setCvv("222");
		bookingPage.setExpMonth("6");
		bookingPage.clickConfirmButton();

	}

	@Then("^Display alert 'please enter expiration year'$")
	public void display_alert_please_enter_expiration_year() throws Throwable {
		String actualErrorMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please fill the expiration year";
		Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.switchTo().alert().accept();				//to accept alert box automatically
		driver.close();
	}


	@When("^all valid data entered$")
	public void all_valid_data_entered() throws Throwable
	{
		bookingPage.setFirstName("Kanchan");
		bookingPage.setLastName("kumari");
		bookingPage.setEmail("Kanchankms95@gmail.com");
		bookingPage.setMobileNo("9999888877");
		bookingPage.setGender("Female");
		bookingPage.setcity("Pune");
		bookingPage.setState("Maharashtra");
		bookingPage.setRoomType("AC");
		bookingPage.setCardHolderName("Kanchan Kumari");
		bookingPage.setDebitNo("458546003211");
		bookingPage.setCvv("222");
		bookingPage.setExpMonth("6");
		bookingPage.setExpYear("2023");
		bookingPage.clickConfirmButton();

	}

	@Then("^Navigate to room booked page$")
	public void navigate_to_room_booked_page() throws Throwable
	{
		driver.navigate().to("D:\\BDD software\\BDD STS Projects\\HotelBookingDemo\\success.html");
		driver.close();
	}
}
